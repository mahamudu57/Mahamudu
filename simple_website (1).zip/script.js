function salamu() {
  alert("Asante kwa kubonyeza! Karibu tena.");
}